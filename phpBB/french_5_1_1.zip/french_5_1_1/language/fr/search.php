<?php
/**
 * This file is part of the French language pack for the
 * phpBB forum software.
 *
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @copyright (c) Qiaeru <https://qiaeru.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * For more information about the language pack, please visit
 * https://www.phpbb.com/customise/db/translation/french/
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, [
	'ALL_AVAILABLE' => 'Tous disponibles',
	'ALL_RESULTS'   => 'Tous les résultats',

	'DISPLAY_RESULTS' => 'Afficher les résultats sous forme de',

	'FOUND_SEARCH_MATCHES' => [
		1 => 'La recherche a renvoyé %d résultat',
		2 => 'La recherche a renvoyé %d résultats',
	],
	'FOUND_MORE_SEARCH_MATCHES' => [
		1 => 'La recherche a renvoyé plus de %d résultat',
		2 => 'La recherche a renvoyé plus de %d résultats',
	],

	'GLOBAL' => 'Annonce générale',

	'IGNORED_TERMS'         => 'ignorés',
	'IGNORED_TERMS_EXPLAIN' => 'Les mots suivants ont été ignorés car ils sont considérés comme trop courants : « %s ».',

	'JUMP_TO_POST' => 'Aller au message',

	'LOGIN_EXPLAIN_EGOSEARCH'    => 'Vous devez être inscrit et connecté pour consulter vos messages.',
	'LOGIN_EXPLAIN_UNREADSEARCH' => 'Vous devez être inscrit et connecté pour consulter vos messages non lus.',
	'LOGIN_EXPLAIN_NEWPOSTS'     => 'Vous devez être inscrit et connecté pour consulter les nouveaux messages publiés depuis votre dernière visite.',

	'MAX_NUM_SEARCH_KEYWORDS_REFINE' => [
		1 => 'Vous avez indiqué trop de mots à rechercher. Ne saisissez pas plus de %1$d mot.',
		2 => 'Vous avez indiqué trop de mots à rechercher. Ne saisissez pas plus de %1$d mots.',
	],

	'NO_KEYWORDS'        => 'Vous devez saisir au moins un mot pour effectuer une recherche. Chaque mot doit comporter au moins %s et ne doit pas dépasser %s, en excluant les astérisques « * » utilisés comme métacaractères passe-partout.',
	'NO_RECENT_SEARCHES' => 'Aucune recherche n’a été effectuée récemment.',
	'NO_SEARCH'          => 'Vous n’êtes pas autorisé à effectuer une recherche.',
	'NO_SEARCH_RESULTS'  => 'Aucun résultat ne correspond à votre recherche.',
	'NO_SEARCH_LOAD'     => 'Recherche indisponible pour le moment : le serveur est en surcharge. Réessayez plus tard.',
	'NO_SEARCH_TIME'     => [
		1 => 'Recherche indisponible pour le moment. Réessayez dans %d seconde.',
		2 => 'Recherche indisponible pour le moment. Réessayez dans %d secondes.',
	],
	'NO_SEARCH_UNREADS' => 'La recherche des messages non lus a été désactivée sur ce forum.',
	'WORD_IN_NO_POST'   => 'Le mot « %s » n’est présent dans aucun message.',
	'WORDS_IN_NO_POST'  => 'Les mots « %s » ne sont présents dans aucun message.',

	'POST_CHARACTERS'        => 'caractères des messages',
	'PHRASE_SEARCH_DISABLED' => 'La recherche par phrase exacte n’est pas prise en charge sur ce forum.',

	'RECENT_SEARCHES'      => 'Recherches récentes',
	'RESULT_DAYS'          => 'Limiter les résultats selon leur ancienneté',
	'RESULT_SORT'          => 'Trier les résultats par',
	'RETURN_FIRST'         => 'Afficher seulement les premiers',
	'RETURN_FIRST_EXPLAIN' => 'Saisissez « 0 » pour afficher le message dans son intégralité.',
	'GO_TO_SEARCH_ADV'     => 'Aller à la recherche avancée',

	'SEARCHED_FOR'             => 'Termes recherchés',
	'SEARCHED_TOPIC'           => 'Sujet recherché',
	'SEARCHED_QUERY'           => 'Requête recherchée',
	'SEARCH_ALL_TERMS'         => 'Rechercher tous les termes ou utiliser la requête telle que saisie',
	'SEARCH_ANY_TERMS'         => 'Rechercher l’un de ces termes',
	'SEARCH_AUTHOR'            => 'Rechercher par auteur',
	'SEARCH_AUTHOR_EXPLAIN'    => 'Utilisez un astérisque « * » comme métacaractère passe-partout pour effectuer des recherches partielles.',
	'SEARCH_FIRST_POST'        => 'Premier message des sujets uniquement',
	'SEARCH_FORUMS'            => 'Rechercher dans les forums',
	'SEARCH_FORUMS_EXPLAIN'    => 'Sélectionnez le ou les forums dans lesquels vous souhaitez effectuer une recherche. Les sous-forums seront automatiquement inclus dans la recherche si vous ne désactivez pas l’option « Rechercher dans les sous-forums » affichée ci-dessous.',
	'SEARCH_IN_RESULTS'        => 'Rechercher dans ces résultats',
	'SEARCH_KEYWORDS_EXPLAIN'  => 'Insérez le caractère « + » devant un mot qui doit être trouvé et « - » devant un mot qui doit être ignoré. Placez entre parenthèses une liste de mots séparés par des barres verticales « | » si un seul de ces mots doit être trouvé. Utilisez un astérisque « * » comme métacaractère passe-partout pour effectuer des recherches partielles.',
	'SEARCH_MSG_ONLY'          => 'Contenu des messages uniquement',
	'SEARCH_OPTIONS'           => 'Options de recherche',
	'SEARCH_QUERY'             => 'Requête de la recherche',
	'SEARCH_SUBFORUMS'         => 'Rechercher dans les sous-forums',
	'SEARCH_TITLE_MSG'         => 'Titres des sujets et contenu des messages',
	'SEARCH_TITLE_ONLY'        => 'Titres des sujets uniquement',
	'SEARCH_WITHIN'            => 'Rechercher dans',
	'SORT_ASCENDING'           => 'Croissant',
	'SORT_AUTHOR'              => 'Auteur',
	'SORT_DESCENDING'          => 'Décroissant',
	'SORT_FORUM'               => 'Forum',
	'SORT_POST_SUBJECT'        => 'Sujet du message',
	'SORT_TIME'                => 'Date du message',
	'SPHINX_SEARCH_FAILED'     => 'Échec de la recherche : %s',
	'SPHINX_SEARCH_FAILED_LOG' => 'Échec de la recherche. Pour plus d’informations, consultez l’historique des erreurs.',

	'TOO_FEW_AUTHOR_CHARS' => [
		1 => 'Saisissez au moins %d caractère du nom de l’auteur.',
		2 => 'Saisissez au moins %d caractères du nom de l’auteur.',
	],
]);
