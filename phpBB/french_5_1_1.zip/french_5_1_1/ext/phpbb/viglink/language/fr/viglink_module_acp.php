<?php
/**
 * This file is part of the French language pack for the
 * VigLink extension for the phpBB forum software package.
 *
 * @copyright (c) 2014 phpBB Limited <https://www.phpbb.com>
 * @copyright (c) Qiaeru <https://qiaeru.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * For more information about the language pack, please visit
 * https://www.phpbb.com/customise/db/translation/french/
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, [
	'ACP_VIGLINK_SETTINGS'         => 'Paramètres de VigLink',
	'ACP_VIGLINK_SETTINGS_EXPLAIN' => 'VigLink est un service tiers qui monétise discrètement les liens publiés par les utilisateurs de votre forum, sans nuire à leur expérience. Lorsqu’un utilisateur clique sur un lien menant à un produit ou service et achète quelque chose chez le marchand partenaire, ce dernier verse à VigLink une commission, dont une partie est reversée au projet phpBB. En activant VigLink et en laissant les commissions au projet phpBB, vous soutenez notre organisation open source et contribuez à sa stabilité financière.',
	'ACP_VIGLINK_SETTINGS_CHANGE'  => 'Vous pouvez modifier ces paramètres à tout moment depuis le panneau « <a href="%1$s">Paramètres de VigLink</a> ».',
	'ACP_VIGLINK_SUPPORT_EXPLAIN'  => 'Vous ne serez plus redirigé vers cette page lorsque vous aurez renseigné les préférences ci-dessous et cliqué sur le bouton « Envoyer ».',
	'ACP_VIGLINK_ENABLE'           => 'Activer VigLink',
	'ACP_VIGLINK_ENABLE_EXPLAIN'   => 'Active l’utilisation des services VigLink.',
	'ACP_VIGLINK_EARNINGS'         => 'Récupérer mes parts de commissions (facultatif)',
	'ACP_VIGLINK_EARNINGS_EXPLAIN' => 'Vous pouvez récupérer vos parts des commissions sur les ventes générées en créant un compte « VigLink Convert ».',
	'ACP_VIGLINK_DISABLED_PHPBB'   => 'Les services VigLink ont été désactivés par phpBB.',
	'ACP_VIGLINK_CLAIM'            => 'Récupérer toutes les parts de commissions',
	'ACP_VIGLINK_CLAIM_EXPLAIN'    => 'Vous pouvez récupérer la totalité des commissions générées par les liens affiliés de votre forum, plutôt que de les reverser au projet phpBB. Pour cela, vous devez disposer d’un compte « VigLink Convert ».',
	'ACP_VIGLINK_CONVERT_ACCOUNT'  => 'Compte « VigLink Convert »',
	'ACP_VIGLINK_NO_CONVERT_LINK'  => 'Le lien vers votre compte « VigLink Convert » est introuvable.',
]);
